Open Terminal> 

sh "drop install.sh here"

Run install.sh in CombaJack first then run the install.sh in alc_fix

By: Italo N.
